
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OBS</title>
</head>
<body>
  
  <h2>Registration</h2>
  <form action="C_check_username.php" method="post">
    
    Email : <input type="email" name="uname" placeholder="Enter Your Email"><br>
    <br>
    Phone Number : <input type="phone" name="phone" placeholder="Enter Your Phone Number"><br>
    <br>
    Password : <input type="password" name="pass" placeholder="Enter Your Password"><br>
    <br>
    Confirm : <input type="password" name="cpass" placeholder="Confirm Your Password"><br>
    <br>

    <input type="submit" name="submit"><br>
  </form> 
</body>
</html>