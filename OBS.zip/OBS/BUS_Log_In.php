
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OBS LOGIN</title>
  <link rel="stylesheet" href="BUS_Log_In.css">
</head>
<body>
  <form action="BUS_loginprocess.php" method="post">
    Location: <input type="text" name="location" placeholder="Share live location Link"><br>
    <br>
    Username:<input type="text" name ="uname" placeholder="Enter Your Email/Username">
    Password:<input type="password" name ="pass" placeholder="Enter Your Password">
    <br>
    <br>
    <input id="submit"
    type="submit" name ="submit">

  </form>

  <h4>If You not Registered, Registered First</h4>
  <a href="BUS.php">Sign Up</a>
  
</body>
</html>
  
