<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OBS</title>
</head>
<body>
  <h3>To Know Bus Location Click Below </h3>
  <a href="https://www.google.com/maps/@23.8337596,90.4162542,17.08z/data=!4m2!7m1!2e1?hl=en"target="_blank">location_projapati_01</a><br><br>
  <a href="https://www.google.com/maps/@23.8337596,90.4162542,17.08z/data=!4m2!7m1!2e1?hl=en"target="_blank">location_projapati_02</a><br><br>
  <a href="https://l.facebook.com/l.php?u=https%3A%2F%2Fmaps.app.goo.gl%2FT1K5wtzwDRGR6Qxu8%3Ffbclid%3DIwAR3RF4kjciRaM-4VmJwKgOCwR-Qt4zRLBW_hRYpxCTwbePAf-zVlibmjwsg&h=AT3kAjpJj5AL6qk6sGXhnlPPnkIXGzAT21PINjeojLv-JpLqIt83FkAvMu2B1vX43RZ_VAfIz9C0PBq-ScFAmLcGodCE9JOBKBs8R7P9KUFYOsS2jgg46rgSsDC_oYXmcIS1fA"target="_blank" >location_projapati_03</a><br><br>
  <h3>To Know Seat Available and Booking Click Below </h3>
  <a href="Projapati_01_Seat.php">Projapati_01_Seat</a><br><br>
  <a href="Projapati_02_Seat.php">Projapati_02_Seat</a><br><br>
  <a href="Projapati_03_Seat.php">Projapati_03_Seat</a><br><br>

  <br>
  
  <p>If you want to go Home please Click Home</p>
  <a href="C_private.php">Home</a>
  <br>
</body>
</html>