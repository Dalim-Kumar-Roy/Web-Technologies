<?php
if(session_status()>=0){
  session_start();
  if(isset($_SESSION["uname"])){
    header("refresh: 1; url = C_private.php");
    //echo $SESSION["uname"];
  }
}



if(isset($_POST["submit"])){
  $uname = $_POST["uname"];

  $conn = mysqli_connect('localhost', 'root', '', 'obss');
  $sql = "SELECT *FROM passenger_info WHERE username = '$uname'";

  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
  $count = mysqli_num_rows($result);
  

  if($count == 1){
    //session_start();
    echo "This Mail already Registered";
    header("refresh: 4; url = C_index.php");
    exit();
  }
  else{
    
    if(($_POST["pass"] == $_POST["cpass"])and($_POST["pass"]!=null)){
      $uname = filter_var($_POST["uname"],FILTER_SANITIZE_EMAIL);
      if(filter_var($uname, FILTER_SANITIZE_EMAIL)){
        $pass = $_POST["pass"];
        $phone = $_POST["phone"];
        $pass = md5($pass);//Encript Password
        $conn = mysqli_connect('localhost', 'root', '', 'obss');//connection string
        $sql = "INSERT INTO passenger_info(username,Phone_Number,password,dt)VALUES('$uname', '$phone', '$pass', current_timestamp())";
        if (mysqli_query($conn, $sql))
        {
          session_start();
          $_SESSION["uname"] = $_POST["uname"];//may be here can solved change user name 
          echo "Registration Accepeted <br>";
          header("refresh: 4; url = C_private.php");
  
        }
        }
        else{
          echo "Email Format is not Correct.";
          header("refresh: 4; url = C_index.php");
        }
      }
      else{
        echo "Password Error, ";
        header("refresh: 4; url = C_index.php");
      }
    }
}


?>  