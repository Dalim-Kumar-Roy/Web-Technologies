<?php
//connecting the database
$server = "localhost";
  $username = "root";
  $password = "";

  $conn = mysqli_connect($server,$username, $password);

  if(!$conn){
    die("connection to this database failed due to " . mysqli_connect_error());
  }
  else{
    echo "Connection was succefuller";
  }
  $sql = "SELECT * FROM `passenger_info`";
  $result = mysqli_query($conn, $sql);
  //find the numbers of records return
  $num = mysqli_num_rows($result);

  ?>
  <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OBS</title>
</head>
<body>
  <br>
  <p>If you want to go Home please Click Home</p>
  <a href="C_private.php">Home</a>
  <br>
</body>
</html>