<?php
  if(session_status()>=0){
    session_start();
    if(isset($_SESSION["uname"])){
      header("refresh: 1; url = C_private.php");
      //echo $SESSION["uname"];
    }
  }

if(isset($_POST["submit"])){
  $uname = $_POST["uname"];
  $pass = $_POST["pass"];
  $pass = md5($pass);//Encript pass

  $conn = mysqli_connect('localhost', 'root', '', 'obss');
  $sql = "SELECT *FROM bus_reg_info WHERE username = '$uname' and password = '$pass'";

  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
  $count = mysqli_num_rows($result);

  if($count == 1){
    session_start();
    $_SESSION["uname"] = $uname;
    echo "You are Redirectedd";
    header("refresh: 4; url = B_private.php");
    exit();
  }
  elseif($count >1){
    echo "Multiple user exists , Account in HOLD";
    header("refresh: 7; url = C_index.php");
    exit();

  }
  else{
    echo "User Not Found.<br>";
    echo "If you not Registert please Click Sign Up first";
    header("refresh: 4; url = BUS.php");
    exit();
  
}
}
if(!isset($_POST["submit"])){
  echo "Fill the user name and Password."."<br>";
  header("refresh: 4; url = C_index.php");
}

?>  