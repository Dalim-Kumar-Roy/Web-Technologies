<?php
  if(session_status()>=0){
    session_start();
    if(isset($_SESSION["uname"])){
      header("refresh: 1; url = C_private.php");
      //echo $SESSION["uname"];
    }
  }

if(isset($_POST["submit"])){
  if($_POST["uname"]=="Author@gmail.com"){
    header("refresh: 2; url = Author.php");
    exit();
  }
  //here start the manager log in
  elseif($_POST["uname"]=="managers@gmail.com"){
    header("refresh: 2; url = managers.php");
    exit();
  }
  //here end the manager login
  else{
  $uname = $_POST["uname"];
  $pass = $_POST["pass"];
  $pass = md5($pass);//Encript pass

  $conn = mysqli_connect('localhost', 'root', '', 'obss');
  $sql = "SELECT *FROM passenger_info WHERE username = '$uname' and password = '$pass'";

  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
  $count = mysqli_num_rows($result);

  if($count == 1){
    session_start();
    $_SESSION["uname"] = $uname;
    echo "You are Redirectedd";
    header("refresh: 2; url = C_private.php");
    exit();
  }
  elseif($count >1){
    echo "Multiple user exists , Account in HOLD";
    header("refresh: 2; url = C_index.php");
    exit();

  }
  else{
    echo "User Not Found.<br>";
    echo "If you not Registert please Click Sign Up first";
    header("refresh: 4; url = C_index.php");
    exit();
  }
}
}
if(!isset($_POST["submit"])){
  echo "Fill the user name and Password."."<br>";
  header("refresh: 4; url = C_index.php");
}

?>  