<?php
  if (session_status()>=0){

    session_start();
    if(isset($_SESSION["uname"])){
     // header("refresh: 1; url = C_private.php");
      //echo $SESSION["uname"];
    }
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OBS</title>
  <link rel="stylesheet" href="C_style.css">
</head>
<body>
  <h3 style="color:Blue">To Log In Fill Up Username and Password , Then Click Submit </h3>
  <div>
  <form action="C_loginprocess.php" method="post">
    Username : <input type="text" name ="uname" placeholder="Enter username as Email">
    Password : <input type="password" name ="pass" placeholder="Enter Your Password">
    <input type="submit" name ="submit">

  </form>
  </div>
  <br>
  <h2 style="color:Blue">If not Registered please Sign Up first</h2>

  <a id="id" href="C_signup.php">Sign Up</a>

  <br>
  <h2 style="color:red">Below, Only For BUS Registered and BUS Log In</h2>
 
  <a id="id" href="BUS.php">BUS_Reg</a><br><br>
  <a id="id" href="BUS_Log_In.php">BUS_LOG_IN</a>

</body>
</html>
