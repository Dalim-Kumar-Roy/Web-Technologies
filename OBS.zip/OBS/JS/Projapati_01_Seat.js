const btn1 = document.getElementById('btn1');
btn1.addEventListener('click', function onClick() {
  btn1.style.backgroundColor = 'salmon';
  btn1.style.color = 'white';
});


const btn2 = document.getElementById('btn2');
btn2.addEventListener('click', function onClick() {
  btn2.style.backgroundColor = 'salmon';
  btn2.style.color = 'white';
});


const btn3 = document.getElementById('btn3');
btn3.addEventListener('click', function onClick() {
  btn3.style.backgroundColor = 'salmon';
  btn3.style.color = 'white';
});


const btn4 = document.getElementById('btn4');
btn4.addEventListener('click', function onClick() {
  btn4.style.backgroundColor = 'salmon';
  btn4.style.color = 'white';
});


const btn5 = document.getElementById('btn5');
btn5.addEventListener('click', function onClick() {
  btn5.style.backgroundColor = 'salmon';
  btn5.style.color = 'white';
});

const btn6 = document.getElementById('btn6');
btn6.addEventListener('click', function onClick() {
  btn6.style.backgroundColor = 'salmon';
  btn6.style.color = 'white';
});

const btn7 = document.getElementById('btn7');
btn7.addEventListener('click', function onClick() {
  btn7.style.backgroundColor = 'salmon';
  btn7.style.color = 'white';
});

const btn8 = document.getElementById('btn8');
btn8.addEventListener('click', function onClick() {
  btn8.style.backgroundColor = 'salmon';
  btn8.style.color = 'white';
});

const btn9 = document.getElementById('btn9');
btn9.addEventListener('click', function onClick() {
  btn9.style.backgroundColor = 'salmon';
  btn9.style.color = 'white';
});

const btn10 = document.getElementById('btn10');
btn10.addEventListener('click', function onClick() {
  btn10.style.backgroundColor = 'salmon';
  btn10.style.color = 'white';
});

const btn11 = document.getElementById('btn11');
btn11.addEventListener('click', function onClick() {
  btn11.style.backgroundColor = 'salmon';
  btn11.style.color = 'white';
});

const btn12 = document.getElementById('btn12');
btn12.addEventListener('click', function onClick() {
  btn12.style.backgroundColor = 'salmon';
  btn12.style.color = 'white';
});

const btn13 = document.getElementById('btn13');
btn13.addEventListener('click', function onClick() {
  btn13.style.backgroundColor = 'salmon';
  btn13.style.color = 'white';
});

const btn14 = document.getElementById('btn14');
btn14.addEventListener('click', function onClick() {
  btn14.style.backgroundColor = 'salmon';
  btn14.style.color = 'white';
});

const btn15 = document.getElementById('btn15');
btn15.addEventListener('click', function onClick() {
  btn15.style.backgroundColor = 'salmon';
  btn15.style.color = 'white';
});

const btn16 = document.getElementById('btn16');
btn16.addEventListener('click', function onClick() {
  btn16.style.backgroundColor = 'salmon';
  btn16.style.color = 'white';
});

const btn17 = document.getElementById('btn17');
btn17.addEventListener('click', function onClick() {
  btn17.style.backgroundColor = 'salmon';
  btn17.style.color = 'white';
});


const btn18 = document.getElementById('btn18');
btn18.addEventListener('click', function onClick() {
  btn18.style.backgroundColor = 'salmon';
  btn18.style.color = 'white';
});

const btn19 = document.getElementById('btn19');
btn19.addEventListener('click', function onClick() {
  btn19.style.backgroundColor = 'salmon';
  btn19.style.color = 'white';
});

const btn20 = document.getElementById('btn20');
btn20.addEventListener('click', function onClick() {
  btn20.style.backgroundColor = 'salmon';
  btn20.style.color = 'white';
});

const btn21 = document.getElementById('btn21');
btn21.addEventListener('click', function onClick() {
  btn21.style.backgroundColor = 'salmon';
  btn21.style.color = 'white';
});

const btn22 = document.getElementById('btn22');
btn22.addEventListener('click', function onClick() {
  btn22.style.backgroundColor = 'salmon';
  btn22.style.color = 'white';
});

const btn23 = document.getElementById('btn23');
btn23.addEventListener('click', function onClick() {
  btn23.style.backgroundColor = 'salmon';
  btn23.style.color = 'white';
});

const btn24 = document.getElementById('btn24');
btn24.addEventListener('click', function onClick() {
  btn24.style.backgroundColor = 'salmon';
  btn24.style.color = 'white';
});

const btn25 = document.getElementById('btn25');
btn25.addEventListener('click', function onClick() {
  btn25.style.backgroundColor = 'salmon';
  btn25.style.color = 'white';
});

const btn26 = document.getElementById('btn26');
btn26.addEventListener('click', function onClick() {
  btn26.style.backgroundColor = 'salmon';
  btn26.style.color = 'white';
});

const btn27 = document.getElementById('btn27');
btn27.addEventListener('click', function onClick() {
  btn27.style.backgroundColor = 'salmon';
  btn27.style.color = 'white';
});

const btn28 = document.getElementById('btn28');
btn28.addEventListener('click', function onClick() {
  btn28.style.backgroundColor = 'salmon';
  btn28.style.color = 'white';
});

const btn29 = document.getElementById('btn29');
btn29.addEventListener('click', function onClick() {
  btn29.style.backgroundColor = 'salmon';
  btn29.style.color = 'white';
});

const btn30 = document.getElementById('btn30');
btn30.addEventListener('click', function onClick() {
  btn30.style.backgroundColor = 'salmon';
  btn30.style.color = 'white';
});

const btn31 = document.getElementById('btn31');
btn31.addEventListener('click', function onClick() {
  btn31.style.backgroundColor = 'salmon';
  btn31.style.color = 'white';
});

const btn32 = document.getElementById('btn32');
btn32.addEventListener('click', function onClick() {
  btn32.style.backgroundColor = 'salmon';
  btn32.style.color = 'white';
});


// Calculate Bus Vara 

var total=0;
btn1.addEventListener('click', function onClick() {
   total= total+50;
   parseInt(total);
document.getElementById('gator').innerHTML =total;
onClick=this.disabled=true;
});

btn2.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn3.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn4.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn5.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn6.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn7.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn8.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total,'Taka';
onClick=this.disabled=true;
});


btn9.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn10.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn11.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn12.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn13.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn14.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn15.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn16.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn17.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn18.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn19.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn20.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn21.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn22.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn23.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn24.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn25.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn26.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn27.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn28.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn29.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});

btn30.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn31.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});


btn32.addEventListener('click', function onClick() {
  total= total+50;
  parseInt(total);
document.getElementById('gator').innerHTML = total;
onClick=this.disabled=true;
});







