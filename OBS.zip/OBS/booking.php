<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Booking Here</title>
  <link rel="stylesheet" href="booking.css">
</head>
<body>
    <h3 style=color:red>Booking Confirm here only Can do BUS</h3>
    <h3 style=color:Green>To Confirm Request BUS/Driver please cllick on LOGIN </h3>
    <a href="BUS_Log_In_Confirm.php">LOGIN</a>
    <br>
    <a href="https://www.bkash.com/bn">Bkash_Payment</a>
    <br>
    <br>
    <a href="https://dutchbanglabank.com/rocket/download.htm">Rocket_Payment</a>
    <br>
    <br>
    <a href="https://nagad.com.bd/">Nagat_Payment</a>
    <br>
    <br>
    <a href="https://www.dutchbanglabank.com/electronic-banking/instantdebitcard.html">Card_Payment</a>
    <br>
    <br>
    <a href="C_index.php">SIGN_OUT</a>
    <br>
</body>
</html>