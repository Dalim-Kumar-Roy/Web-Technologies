<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BUS PRIVATE</title>
  <link rel="stylesheet" href="B_private.css">
</head>
<body>
  <h2>সময়ের চেয়ে জীবনের মূল্য অনেক বেশি</h2>
  <h3>SAFETY FIRST</h3> 
  <h3>HAPPY JOURNEY</h3>
  <br>
  <p> To see Passenger Request ,Click on Booking  </P>
  <a href="booking.php">Booking</a>
  <br>
  <br>
  <a href="C_index.php">SIGN_OUT</a>

</body>
</html>
