<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Journey Details </title>
  <link rel="stylesheet" href="Journey.css">
</head>
<body>
  <div>
  <br>
  <br>
  <h1>Welcome to Journey</h1>
  <h3>To Know Bus Name click Here </h3>
  <a href="Kuril_to_Mirpur_1.php">Bus_Name</a>
  <br>
  <p>If you want to go Home please Click Home</p>
  <a href="C_private.php">Home</a>
  <br>
  <br>
  </div>
</body>
</html>