<?php
if (session_status()>=0 ){
  session_start();
  session_unset();

  session_destroy();
  echo "You are now redirected";
}
header("refresh: 4; url = C_index.php");
?>