<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<!-- Op TH-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- JS -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <title>OBS</title>
  <link rel="stylesheet" href="Projapati_01_Seat.css">
  
</head>
<body>
  <br>
  <br>
<!-- <h3 style="background: rgb(200, 139, 208); color:blue;padding:10px;font-size:20px;margin-left: 250px;margin-right: 250px; border: 1px solid blue">Available Seat Color</h3>

<h3 style="background-color:salmon;color:white;padding:10px;font-size:20px;margin-left: 250px;margin-right: 250px;">Select Seat Color </h3> -->

<div class="container">
<div class="row">
<div class="col-12 col-sm-12 col-lg-12 col-md-12">

<h1>Here Seat List </h1>

</div>
</div>
<div class="row">
<div class="col-12 col-sm-12 col-lg-12 col-md-12">

</div>
</div>
<!--<form action="Bus_info.php" method="post">-->
<div class="row">
<div class="col-12 col-sm-12 col-lg-8 col-md-12">
      <form>
      <!-- <b>Seat_01</b> -->
      <div class="row">
<div class="col-12 col-sm-12 col-lg-12 col-md-12">
      <button id="btn1" type="button" class="btn btn-outline-primary">Seat_01</button>
      <button id="btn2" type="button"  class="btn btn-outline-primary">Seat_02</button>
      <button  type="button" class="space"> space </button>
      <button id="btn3" type="button" class="btn btn-outline-primary">Seat_03</button>
      <button id="btn4" type="button" class="btn btn-outline-primary">Seat_04</button>
      <br>
</div>
</div>
      <button id="btn5" type="button" class="btn btn-outline-primary">Seat_05</button>
      <button id="btn6" type="button" class="btn btn-outline-primary">Seat_06</button>
      <button  type="button" class="space"> space </button>
      <button id="btn7" type="button" class="btn btn-outline-primary">Seat_07</button>
      <button id="btn8" type="button" class="btn btn-outline-primary">Seat_08</button>
      <br>
      <button id="btn9" type="button" class="btn btn-outline-primary">Seat_09</button>
      <button id="btn10" type="button" class="btn btn-outline-primary">Seat_10</button>
      <button class="space"  type="button"> space </button>
      <button id="btn11" class="btn btn-outline-primary"  type="button">Seat_11</button>
      <button id="btn12" class="btn btn-outline-primary"  type="button">Seat_12</button>
      <br>
      <button id="btn13" class="btn btn-outline-primary"  type="button">Seat_13</button>
      <button id="btn14" class="btn btn-outline-primary"  type="button">Seat_14</button>
      <button class="space"  type="button"> space </button>
      <button id="btn15" class="btn btn-outline-primary"  type="button">Seat_15</button>
      <button id="btn16" class="btn btn-outline-primary"  type="button">Seat_16</button>
      <br>
      <button id="btn17" class="btn btn-outline-primary" type="button">Seat_17</button>
      <button id="btn18" class="btn btn-outline-primary" type="button">Seat_18</button>
      <button class="space"> space </button>
      <button id="btn19" class="btn btn-outline-primary" type="button">Seat_19</button>
      <button id="btn20" class="btn btn-outline-primary" type="button">Seat_20</button>
      <br>
      <button id="btn21" class="btn btn-outline-primary" type="button">Seat_21</button>
      <button id="btn22" class="btn btn-outline-primary" type="button">Seat_22</button>
      <button class="space"> space </button>
      <button id="btn23" class="btn btn-outline-primary" type="button">Seat_23</button>
      <button id="btn24" class="btn btn-outline-primary" type="button">Seat_24</button>
      <br>
      <button id="btn25" class="btn btn-outline-primary" type="button">Seat_25</button>
      <button id="btn26" class="btn btn-outline-primary" type="button">Seat_26</button>
      <button class="space" type="button"> space </button>
      <button id="btn27" class="btn btn-outline-primary" type="button">Seat_27</button>
      <button id="btn28" class="btn btn-outline-primary"  type="button">Seat_28</button>
      <br>
      <button id="btn29" class="btn btn-outline-primary" type="button">Seat_29</button>
      <button id="btn30" class="btn btn-outline-primary" type="button">Seat_30</button>
      <button class="space"> space </button>
      <button id="btn31" class="btn btn-outline-primary" type="button">Seat_31</button>
      <button id="btn32" class="btn btn-outline-primary" type="button">Seat_32</button>
      <br>
     

    </form>
</div>
<div id="gator" class="col-12 col-sm-12 col-lg-4 col-md-12">

</div>
</div>
<div class="row">
<div class="col-12 col-sm-12 col-lg-12 col-md-12">
    <h2>Please Payment : </h2>
    <form>
      
    <a href="booking.php">Payment</a>
    </form>
</div>
</div>
  <br>
  <div class="row">
  <div class="col-12 col-sm-12 col-lg-12 col-md-12">
  <h3>If you want to go Home please Click Home</h3>
  <a href="C_private.php">Home</a>
</div>
</div>
  <br>

  <script src="js/Projapati_01_Seat.js">
   

  </script>
  </div>
</body>
</html>

<?php

?>