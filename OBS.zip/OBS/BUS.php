<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OBS</title>
  <link rel="stylesheet" href="BUS.css">
</head>
<body>
  
  <h2>Registration</h2>
  <form action="Bus_info.php" method="post">
    Bus_Name : <input type="text" name="b_name" placeholder="Enter Bus Name "><br>
    <br>
    Bus_License : <input type="text" name="b_l" placeholder="Enter Bus_License_no "><br>
    <br>
    
    Driver_Name : <input type="text" name="d_name" placeholder="Enter Driver Name "><br>
    <br>
    D_Licencse_No : <input type="text" name="d_l" placeholder="Enter Driving L_no "><br>
    <br>
    Email : <input type="email" name="uname" placeholder="Enter Your Email"><br>
    <br>
    Phone Number : <input type="phone" name="phone" placeholder="Enter Your Phone Number"><br>
    <br>
    Password : <input type="password" name="pass" placeholder="Enter Your Password"><br>
    <br>
    Confirm : <input type="password" name="cpass" placeholder="Confirm Your Password"><br>
    <br>
    <input id="submit" type="submit" name="submit"><br>
  </form>
  <br>
  <p >If you want to Main Page Click below</p>
  <a href="C_index.php">Main</a>
  <br>
</body>
</html>