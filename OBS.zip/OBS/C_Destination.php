<?php
if(isset($_POST["submit"])){
  if($_POST["start"] != $_POST["end"]){
      $start = $_POST["start"];
      $end = $_POST["end"];
      $conn = mysqli_connect('localhost', 'root', '', 'obss');//connection string
      $sql = "INSERT INTO destination_info(start,end)VALUES('$start', '$end')";
      if (mysqli_query($conn, $sql))
      {
        session_start();
        echo "Registration in destination_info to count search <br>";
        if(($start=="AIUB")and ($end=="mirpur1")){
        header("refresh: 1; url = Journey.php");
      }
      else{
        echo "<h3>SORRY</h3>";
        echo "<h4>Now this Destination not Services</h4>";
        echo "<h4>We Will Started this Services AS SOON AS POSSIBLE</h4>";
        echo "<h3>Thank You</h3>";
        echo "Please Wait 5 sec , You Redirected in HOME";
        header("refresh: 5; url = C_private.php");
      }

      }
     
    }
    else{
      echo "Make Sure From and To";
      header("refresh: 4; url = C_private.php");
    }
  }
  else{
    if(session_status() == PHP_SESSION_NONE){}
    header("location:C_index.php");
}

?>