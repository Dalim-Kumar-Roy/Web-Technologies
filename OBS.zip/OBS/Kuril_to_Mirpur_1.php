
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OBS</title>
  <link rel="stylesheet" href="Kuril_to_Mirpur_1.css">
</head>
<body>
<h1>Here the Bus List</h1>
<a href="paristhan.php">paristhan</a>
<a href="projapati.php">projapati</a>
<br>

<br>
  <h2>If you want to go Home please Click Home</h2>
  <a href="C_private.php">Home</a>
  <br>
</body>
</html>