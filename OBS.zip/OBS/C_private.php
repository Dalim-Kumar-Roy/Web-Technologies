<?php
$token = "";
$token2 = "";
session_start();
if(isset($_SESSION["uname"])){
  echo "<h1 style=\"color:red\">"."Hello Congratulaions"."</h1>" ;
  echo "<h3>You are Loged in</h3>";
  $token ="C_signout.php";
  $token2 = "Sign Out";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OBS</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="C_private.css">
</head>
<body>
  <!-- <img class="bg" src="bus.jpg" alt="BUS"> Here the Background -->
  <p style="text-align:left">
  <div>
  <?php
  if(isset($_SESSION["uname"])){
    
    echo "Username: "."<b style=\"color:red\">".$_SESSION["uname"]."</b><br>";
    
  }
  ?> 
  </div>
  <h1>Welcome to Our Servicess </h1>
  <h3>Fill Up From and To , to booking seat and CLICK on Submit</h3>
<form action="C_Destination.php" method="post" class="from">
    
    From: <input type="text" name="start" placeholder="Enter From " >
    To: <input type="text" name="end" placeholder="Enter where you want to go ">
    <input id="submit" type="submit" name="submit"><br>
  </form> 

  <br>
  <!--<img class="" src="bus.jpg" alt="BUS">-->
  <br>
  <br>
  <p class="p">If you want to Refresh please Click Home</p>
  <a href="C_private.php">Home</a>
  <br>
  <br>
  <p class="p">If you want to signout please click below in Sign Out</p>
  <a href="C_signout.php">SignOut</a>
  
</body>
</html>