
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>managers</title>
  <link rel="stylesheet" href="Managers.css">
</head>
<body>
<h1>Welcome To Mangers</h1> <h2>Work and Enjoy </h2>
  <h3> See Booking list Click Booking </h3>
  <a href="booking.php">Booking</a>
  <br>
  <br>
  <h3>Paseengers Home please Click Home</h3>
  <a href="C_private.php">Home</a>
  <br>
  <br>
  <a href="C_index.php">SIGN_OUT</a>
</body>
</html>