
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OBS BUS LOGIN</title>
  <link rel="stylesheet" href="Bus_Log_In_Confirm.css">
</head>
<body>
  <div>
  <form action="BUS_loginprocess_Confirm.php" method="post">
    <br>
    Location: <input type="text" name="location" placeholder="Share live location Link"><br>
    <br>
    Username:<input type="text" name ="uname" placeholder="Enter your email/username">
    <br>
    <br>
    Password:<input type="password" name ="pass" placeholder="Enter Your password">
    <br>
    <br>
    <input id="submit" type="submit" name ="Submit">
    <br>

  </form>
  <br>
  </div>
  <br>
  <br>
  <a href="C_index.php">SIGN_OUT</a>
  
</body>
</html>
  
