<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="Managers_Requirement.css">
  <title>OBS Mangaers Requirement </title>
</head>
<body>
  
  <h2>Registration</h2>
  <form action="Managers_info.php" method="post">
    Manager_Name : <input type="text" name="b_name" placeholder="Enter Manager Name"><br>
    <br>
    Age : <input type="text" name="b_l" placeholder="Enter Manager Age "><br>
    <br>
    Email : <input type="email" name="uname" placeholder="Enter Managers Email"><br>
    <br>
    Phone Number : <input type="phone" name="phone" placeholder="Enter Manager Phone Number"><br>
    <br>
    Password : <input type="password" name="pass" placeholder="Enter Manager Password"><br>
    <br>
    Confirm Password: <input type="password" name="cpass" placeholder="Confirm Manager Password"><br>
    <br>
    <input id="submit" type="submit" name="submit"><br>
  </form>
  <br>
  <br>
  <a href="Author.php">CEO_HOME</a>
  <br>
  <br>
  <a href="C_index.php">SIGN_OUT</a>
  <br>
</body>
</html>